This repo will document the process to pair a systems netflow data with the windows processes that created each flow.

Series 1

Warning, videos have no audio.  Unable to aquire license rights to wind beneath my wings, take the power back, fade to black or anything from Mr. Oz Osbourne, so whats the point?

Suricata IDS on Windows 10 Part 1
https://www.youtube.com/watch?v=h0FJx-eYkxQ

Suricata IDS on Windows 10 Part 2
https://www.youtube.com/watch?v=uwLBxTAIa3s&t=40s

------------------------------------------------------------------------------------------------------------------
Series 2

Netstat -anoob OUTPUT to sqlite using powershell Part 1

https://www.youtube.com/watch?v=I8Yp57_kGzM

This series is inspired by this tweet!
https://twitter.com/egyp7/status/9594...

@egyp7 
"Can confirm. CCDC has taught me that it is difficult to avoid the IDS that is a human looking at netstat and Wireshark continuously"



